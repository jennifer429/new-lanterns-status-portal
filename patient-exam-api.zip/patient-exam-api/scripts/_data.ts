import fs from "node:fs";
import path from "node:path";
import type { Request } from "../src/types.ts";

export type Label = { case_id: string; study_id: string; is_relevant_to_current: boolean };
export type PublicDataset = Request & { truth: Label[] };

const CANDIDATE_PATHS = [
  "data/public.json",
  "relevant_priors_public (1).json",
  "relevant_priors_public.json",
];

export function loadPublic(file?: string): PublicDataset {
  const searched: string[] = [];
  const candidates = file
    ? [file]
    : CANDIDATE_PATHS.map((p) => path.join(process.cwd(), p));
  for (const p of candidates) {
    searched.push(p);
    if (fs.existsSync(p)) {
      const raw = JSON.parse(fs.readFileSync(p, "utf8"));
      if (!raw.cases || !raw.truth) {
        throw new Error(`Expected both 'cases' and 'truth' in ${p}`);
      }
      return raw as PublicDataset;
    }
  }
  throw new Error(
    `Public dataset not found. Searched:\n  ${searched.join("\n  ")}`,
  );
}

export function labelIndex(truth: Label[]): Map<string, boolean> {
  const m = new Map<string, boolean>();
  for (const t of truth) m.set(`${t.case_id}|${t.study_id}`, t.is_relevant_to_current);
  return m;
}
